# BitcoinTicker
Learn to make iOS Apps with [The App Brewery](https://www.appbrewery.co) 📱 | Project Stub | (Swift 4.0/Xcode 9) - Bitcoin Ticker App

Beginner: Download the starter project files as .zip and extract the files to your desktop.

Pro: Git clone to your Xcode projects folder.

## Finished App
![Finished App](http://i.giphy.com/l0HlQGzz2MQCKIBI4.gif)

Copyright © The App Brewery
